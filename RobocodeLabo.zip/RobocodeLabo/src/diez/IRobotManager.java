package diez;

import robocode.JuniorRobot;

public interface IRobotManager {
    IStrategy strategy();
}